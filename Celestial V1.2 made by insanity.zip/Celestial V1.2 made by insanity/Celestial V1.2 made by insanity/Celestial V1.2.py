import os #line:1
import requests #line:2
import socket #line:3
import subprocess #line:4
from datetime import datetime #line:5
logo ="""
\033[38;2;75;0;130m ▄████▄  ▓█████  ██▓    ▓█████  ██████ ▄▄▄█████▓  ██▓ ▄▄▄       ██▓   
\033[38;2;75;0;130m▒██▀ ▀█  ▓█   ▀ ▓██▒    ▓█   ▀▒██    ▒ ▓  ██▒ ▓▒▒▓██▒▒████▄    ▓██▒   
\033[38;2;75;0;130m▒▓█    ▄ ▒███   ▒██░    ▒███  ░ ▓██▄   ▒ ▓██░ ▒░▒▒██▒▒██  ▀█▄  ▒██░   
\033[38;2;75;0;130m▒▓▓▄ ▄██ ▒▓█  ▄ ▒██░    ▒▓█  ▄  ▒   ██▒░ ▓██▓ ░ ░░██░░██▄▄▄▄██ ▒██░   
\033[38;2;75;0;130m▒ ▓███▀ ▒░▒████▒░██████▒░▒████▒██████▒▒  ▒██▒ ░ ░░██░▒▓█   ▓██▒░██████
\033[38;2;75;0;130m░ ░▒ ▒  ░░░ ▒░ ░░ ▒░▓  ░░░ ▒░ ▒ ▒▓▒ ▒ ░  ▒ ░░    ░▓  ░▒▒   ▓▒█░░ ▒░▓  
\033[38;2;75;0;130m  ░  ▒  ░ ░ ░  ░░ ░ ▒  ░ ░ ░  ░ ░▒  ░ ░    ░    ░ ▒ ░░ ░   ▒▒ ░░ ░ ▒  
\033[38;2;75;0;130m░           ░     ░ ░      ░  ░  ░  ░    ░      ░ ▒ ░  ░   ▒     ░ ░  
\033[38;2;75;0;130m░ ░     ░   ░  ░    ░  ░   ░        ░             ░        ░  ░    ░  
\033[38;2;255;0;0mAuthor: Insanity
"""#line:18
def print_option_table ():#line:20
    print ("\033[38;2;75;0;130m┌─────────────────────────────────────────────────────────────────────┐")#line:21
    print ("\033[38;2;75;0;130m│\033[38;2;255;255;255m [1] IP Lookup                 │ [5] Whois Lookup            │")#line:22
    print ("\033[38;2;75;0;130m│\033[38;2;255;255;255m [2] Webhook Sender            │ [6] Ping IP                 │")#line:23
    print ("\033[38;2;75;0;130m│\033[38;2;255;255;255m [3] Show HWID                 │ [7] Port Scan               │")#line:24
    print ("\033[38;2;75;0;130m│\033[38;2;255;255;255m [4] DNS Lookup                │ [8] Traceroute              │")#line:25
    print ("\033[38;2;75;0;130m│\033[38;2;255;255;255m [9] Exit                      │                             │")#line:26
    print ("\033[38;2;75;0;130m└─────────────────────────────────────────────────────────────────────┘")#line:27
def wait_for_user ():#line:29
    input ("Press Enter to continue...")#line:30
def getHwid ():#line:32
    print ("\033[38;2;255;0;0mCPU Serial\033[38;2;255;255;255m")#line:33
    os .system ("wmic cpu get ProcessorId")#line:34
    print ("\033[38;2;255;0;0mDisk Serial\033[38;2;255;255;255m")#line:36
    os .system ("wmic diskdrive get SerialNumber")#line:37
    print ("\033[38;2;255;0;0mMotherboard Serial\033[38;2;255;255;255m")#line:39
    os .system ("wmic baseboard get SerialNumber")#line:40
def send_to_discord (OOOOO0O00OO0O0000 ,OOO0OOOO0O00O00OO ,OOO00OO0OOO00OO0O ):#line:42
    O0OO00O0O0OO0OOO0 ={"content":OOO0OOOO0O00O00OO ,"username":OOO00OO0OOO00OO0O }#line:46
    OO0000O0OOO0OO000 =requests .post (OOOOO0O00OO0O0000 ,json =O0OO00O0O0OO0OOO0 )#line:48
    if OO0000O0OOO0OO000 .status_code ==204 :#line:50
        print ("\033[38;2;0;0;255mMessage sent successfully.\033[38;2;255;255;255m")#line:51
    else :#line:52
        print (f"\033[38;2;255;0;0mFailed to send message: {OO0000O0OOO0OO000.status_code} - {OO0000O0OOO0OO000.text}")#line:53
def dns_lookup (O0O0O00OO00O0OO0O ):#line:55
    try :#line:56
        O0OOO0OO000O000OO =socket .gethostbyname (O0O0O00OO00O0OO0O )#line:57
        print (f"\033[38;2;0;0;255mDomain:\033[38;2;255;255;255m {O0O0O00OO00O0OO0O}")#line:58
        print (f"\033[38;2;0;0;255mIP Address:\033[38;2;255;255;255m {O0OOO0OO000O000OO}")#line:59
        print ("\nAdditional DNS Information (Nameservers):\033[38;2;255;255;255m")#line:61
        O00O000000OO0O0O0 =requests .get (f"https://dns.google/resolve?name={O0O0O00OO00O0OO0O}")#line:62
        if O00O000000OO0O0O0 .status_code ==200 :#line:63
            O00O00O00O00OO0OO =O00O000000OO0O0O0 .json ()#line:64
            for O0OO000O000O0OOOO in O00O00O00O00OO0OO .get ("Answer",[]):#line:65
                if O0OO000O000O0OOOO ["type"]==1 :#line:66
                    print (f" - A Record: {O0OO000O000O0OOOO['data']}")#line:67
                elif O0OO000O000O0OOOO ["type"]==2 :#line:68
                    print (f" - NS Record: {O0OO000O000O0OOOO['data']}")#line:69
        else :#line:70
            print ("Failed to fetch DNS information from the API.")#line:71
    except Exception as OO0OOO000O0OO0000 :#line:72
        print (f"DNS Lookup failed: {str(OO0OOO000O0OO0000)}")#line:73
def whois_lookup (O0O0OOO0OOO00OO00 ):#line:75
    print ("\033[38;2;0;0;255mWhois Lookup for Domain:\033[38;2;255;255;255m",O0O0OOO0OOO00OO00 )#line:76
    try :#line:77
        OOOOO00000OOOOOOO =requests .get (f"https://jsonwhoisapi.com/api/v1/whois?identifier={O0O0OOO0OOO00OO00}",headers ={"Authorization":"Token WgT9cEa22zjWSuiMj2R_Wg"})#line:79
        if OOOOO00000OOOOOOO .status_code ==200 :#line:80
            O0OO000O0OO000O0O =OOOOO00000OOOOOOO .json ()#line:81
            print (f"\033[38;2;0;0;255mRegistrar:\033[38;2;255;255;255m {O0OO000O0OO000O0O.get('registrar', 'N/A')}")#line:82
            print (f"\033[38;2;0;0;255mRegistrant:\033[38;2;255;255;255m {O0OO000O0OO000O0O.get('registrant', {}).get('name', 'N/A')}")#line:83
            print (f"\033[38;2;0;0;255mCreation Date:\033[38;2;255;255;255m {O0OO000O0OO000O0O.get('creation_date', 'N/A')}")#line:84
            print (f"\033[38;2;0;0;255mExpiration Date:\033[38;2;255;255;255m {O0OO000O0OO000O0O.get('expiration_date', 'N/A')}")#line:85
            print (f"\033[38;2;0;0;255mNameservers:\033[38;2;255;255;255m {', '.join(O0OO000O0OO000O0O.get('nameservers', []))}")#line:86
        else :#line:87
            print (f"Failed to fetch Whois data: {OOOOO00000OOOOOOO.status_code} - {OOOOO00000OOOOOOO.text}")#line:88
    except Exception as OO00OOOO0OOOO0OO0 :#line:89
        print (f"Whois Lookup failed: {str(OO00OOOO0OOOO0OO0)}")#line:90
def ping_ip (OOOOO00O000OOOOOO ):#line:92
    print (f"\033[38;2;75;0;130mPinging IP: \033[38;2;255;255;255m{OOOOO00O000OOOOOO}")#line:93
    try :#line:94
        OO0OOO0O0O0O0OOOO =subprocess .run (['ping','-n','4',OOOOO00O000OOOOOO ],stdout =subprocess .PIPE ,stderr =subprocess .PIPE ,text =False )#line:96
        OO000OOO0O00000O0 =OO0OOO0O0O0O0OOOO .stdout .decode ('utf-8',errors ='replace')#line:99
        print (OO000OOO0O00000O0 )#line:100
    except Exception as O0O0OOO0OO0OO0OO0 :#line:101
        print (f"Ping failed: {str(O0O0OOO0OO0OO0OO0)}")#line:102
def port_scan (O0OOO0OO0OOO00O00 ,O0OO00OOOO0OO000O ):#line:104
    print (f"\033[38;2;75;0;130mScanning Ports for {O0OOO0OO0OOO00O00}...\033[38;2;255;255;255m")#line:105
    OO000OO00OOO0OOOO =[]#line:106
    for OOOO0OOOO000O00OO in O0OO00OOOO0OO000O :#line:107
        O00O00OOOO0OO0O00 =socket .socket (socket .AF_INET ,socket .SOCK_STREAM )#line:108
        O00O00OOOO0OO0O00 .settimeout (1 )#line:109
        O00OOOO0O0O0OO0OO =O00O00OOOO0OO0O00 .connect_ex ((O0OOO0OO0OOO00O00 ,OOOO0OOOO000O00OO ))#line:110
        if O00OOOO0O0O0OO0OO ==0 :#line:111
            print (f"\033[38;2;0;255;0mPort {OOOO0OOOO000O00OO} is OPEN\033[38;2;255;255;255m")#line:112
            OO000OO00OOO0OOOO .append (OOOO0OOOO000O00OO )#line:113
        else :#line:114
            print (f"\033[38;2;255;0;0mPort {OOOO0OOOO000O00OO} is CLOSED\033[38;2;255;255;255m")#line:115
        O00O00OOOO0OO0O00 .close ()#line:116
    return OO000OO00OOO0OOOO #line:117
def traceroute (OOO00OOOO0OO0OO00 ):#line:119
    print (f"\033[38;2;75;0;130mRunning Traceroute to {OOO00OOOO0OO0OO00}...\033[38;2;255;255;255m")#line:120
    try :#line:121
        OO0O0O0O00OOOOO0O =subprocess .run (['tracert',OOO00OOOO0OO0OO00 ],stdout =subprocess .PIPE ,stderr =subprocess .PIPE ,text =True )#line:122
        print (OO0O0O0O00OOOOO0O .stdout )#line:123
    except Exception as O0O0000OO00O0O000 :#line:124
        print (f"Traceroute failed: {str(O0O0000OO00O0O000)}")#line:125
while True :#line:128
    os .system ("title Celestial V1.2")#line:129
    os .system ("cls")#line:130
    print (logo )#line:131
    print_option_table ()#line:132
    X =input ("\033[38;2;75;0;130mOption: \033[38;2;255;255;255m")#line:134
    if X =="1":#line:136
        os .system ("cls")#line:137
        print ("\033[38;2;75;0;130mIP LOOKUP\n\033[38;2;255;255;255m")#line:138
        ip =input ("Enter IP: ")#line:139
        r =requests .get (f"http://ip-api.com/json/{ip}")#line:140
        data =r .json ()#line:141
        print ("")#line:142
        print (f"\033[38;2;0;0;255mCountry:\033[38;2;255;255;255m {data['country']}")#line:143
        print (f"\033[38;2;0;0;255mCity:\033[38;2;255;255;255m {data['city']}")#line:144
        print (f"\033[38;2;0;0;255mRegion:\033[38;2;255;255;255m {data['regionName']}")#line:145
        print (f"\033[38;2;0;0;255mTimeZone:\033[38;2;255;255;255m {data['timezone']}")#line:146
        print ("")#line:147
        wait_for_user ()#line:148
    elif X =="2":#line:150
        os .system ("cls")#line:151
        print ("\033[38;2;75;0;130mWEBHOOK SENDER\n\033[38;2;255;255;255m")#line:152
        url =input ("Webhook URL: ")#line:153
        message =input ("Message: ")#line:154
        botname =input ("Botname: ")#line:155
        send_to_discord (url ,message ,botname )#line:156
        wait_for_user ()#line:157
    elif X =="3":#line:159
        os .system ("cls")#line:160
        print ("\033[38;2;75;0;130mHWID\n\033[38;2;255;255;255m")#line:161
        getHwid ()#line:162
        wait_for_user ()#line:163
    elif X =="4":#line:165
        os .system ("cls")#line:166
        print ("\033[38;2;75;0;130mDNS LOOKUP\n\033[38;2;255;255;255m")#line:167
        domain =input ("Enter Domain: ")#line:168
        dns_lookup (domain )#line:169
        wait_for_user ()#line:170
    elif X =="5":#line:172
        os .system ("cls")#line:173
        print ("\033[38;2;75;0;130mWHOIS LOOKUP\n\033[38;2;255;255;255m")#line:174
        domain =input ("Enter Domain: ")#line:175
        whois_lookup (domain )#line:176
        wait_for_user ()#line:177
    elif X =="6":#line:179
        os .system ("cls")#line:180
        print ("\033[38;2;75;0;130mPING IP\n\033[38;2;255;255;255m")#line:181
        ip =input ("Enter IP: ")#line:182
        ping_ip (ip )#line:183
        wait_for_user ()#line:184
    elif X =="7":#line:186
        os .system ("cls")#line:187
        print ("\033[38;2;75;0;130mPORT SCAN\n\033[38;2;255;255;255m")#line:188
        target_ip =input ("Enter target IP: ")#line:189
        ports =[22 ,80 ,443 ,8080 ,21 ]#line:190
        open_ports =port_scan (target_ip ,ports )#line:191
        print (f"\033[38;2;75;0;130mOpen Ports:\033[38;2;255;255;255m {open_ports}")#line:192
        wait_for_user ()#line:193
    elif X =="8":#line:195
        os .system ("cls")#line:196
        print ("\033[38;2;75;0;130mTRACEROUTE\n\033[38;2;255;255;255m")#line:197
        target_ip =input ("Enter target IP or domain: ")#line:198
        traceroute (target_ip )#line:199
        wait_for_user ()#line:200
    elif X =="9":#line:202
        break #line:203
